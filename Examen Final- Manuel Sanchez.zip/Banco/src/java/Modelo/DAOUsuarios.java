package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Manuel S.
 */
public class DAOUsuarios {
    
public DAOUsuarios(){
    
}
    public void insertarC(int id, String nom, String ape) {
        try {
            Conexion con = new Conexion();
            Connection access = con.getConnection();
            String sql = "INSERT INTO cliente VALUES("+id+",'"+nom+"','"+ape+"')";
            PreparedStatement pstm = access.prepareStatement(sql);
            pstm.executeUpdate();
            //JOptionPane.showMessageDialog(null, "Inserción Correcto");
            System.out.println("Inserción Correcto");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Inserción Erronea: " + e);
            System.out.println("Inserción Erronea: "+e);
        }
    }
    public void insertarCB(int nc, int id, String fecha, double monto) {
        try {
            Conexion con = new Conexion();
            Connection access = con.getConnection();
            String sql = "INSERT INTO cuenta_bancaria VALUES("+nc+","+id+",'"+fecha+"',"+monto+")";
            PreparedStatement pstm = access.prepareStatement(sql);
            pstm.executeUpdate();
            //JOptionPane.showMessageDialog(null, "Inserción Correcto");
            System.out.println("Inserción Correcto");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Inserción Erronea: " + e);
            System.out.println("Inserción Erronea: "+e);
        }
    }

    public void actualizarCliente(int id, String nom, String ape) {
        try {
            Conexion con = new Conexion();
            Connection access = con.getConnection();
            String sql = "UPDATE cliente SET nombre='" + nom + "',apellido='" + ape + "' WHERE cedula= " + id + "";
            PreparedStatement pstm = access.prepareStatement(sql);
            pstm.executeUpdate();
            //JOptionPane.showMessageDialog(null, "actualizar correcto");
            System.out.println("actualizar correcto");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "actualizar error: " + e);
            System.out.println("actualizar error: " + e);
        }
    }
    public void actualizarCuenta(int nc, int id, String fechaA, double monto) {
        try {
            Conexion con = new Conexion();
            Connection access = con.getConnection();
            String sql = "UPDATE cuenta_bancaria SET cedula="+id+", fecha_apertura='" + fechaA + "',monto='" + monto + "' WHERE numero_cuenta= " + nc + "";
            PreparedStatement pstm = access.prepareStatement(sql);
            pstm.executeUpdate();
            //JOptionPane.showMessageDialog(null, "actualizar correcto");
            System.out.println("actualizar correcto");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "actualizar error: " + e);
            System.out.println("actualizar error: " + e);
        }
    }

    public void deleteCuenta(int id) {
        try {
            Conexion con = new Conexion();
            Connection access = con.getConnection();
            String sql = "DELETE FROM cuenta_bancaria WHERE cedula=" + id + "";
            PreparedStatement pstm = access.prepareStatement(sql);
            pstm.executeUpdate();
            //JOptionPane.showMessageDialog(null, "eliminar correcto");
            System.out.println("eliminar correcto");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, e);
            System.out.println(" "+e);
        }
    }
    public void registrarRetiro(int numC, String Fecha, double ret){
        //Corregir método    
        try {
            Conexion con = new Conexion();
            Connection access = con.getConnection();
            String sql = "UPDATE cuenta_bancaria SET monto="+ret+" WHERE numero_cuenta=" + numC + "";
            PreparedStatement pstm = access.prepareStatement(sql);
            pstm.executeUpdate();
            //JOptionPane.showMessageDialog(null, "eliminar correcto");
            System.out.println("REgistrar Retiro correcto");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, e);
            System.out.println(" "+e);
        }
    }
    public void RegistrarConsignacion(int nC, String Fecha, double valor){
        //Corregir método    
        try {
            Conexion con = new Conexion();
            Connection access = con.getConnection();
            String sql = "UPDATE cuenta_bancaria SET monto="+valor+" WHERE numero_cuenta=" + nC + "";
            PreparedStatement pstm = access.prepareStatement(sql);
            pstm.executeUpdate();
            //JOptionPane.showMessageDialog(null, "eliminar correcto");
            System.out.println("Registrar Consignación correcto");
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, e);
            System.out.println(" "+e);
        }
    }

   public ResultSet listarCliente(){
       Conexion con = new Conexion();
       String com = "SELECT * FROM cliente";
       ResultSet rs = con.getDatos(com);
       return rs;
   }
   public ResultSet mostrarCliente(){
       Conexion con = new  Conexion();
       String com = "SELECT cedula, nombre FROM cliente";
       ResultSet rs = con.getDatos(com);
       return rs;
   }
   public void PedirPrestamo(double Presta, int tiempo, int valorInteres,String fechaIni, String fechaFin){
       
   }
   public void PagarPrestamo(double Presta, int tiempo, int valorInteres,String fechaIni, String fechaFin){
       
   }
}

package Modelo;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Controlador.Servlet1;

public class Conectar {

    public String user = "sebastian";
    public String password = "1234";
    public String url = "jdbc:derby://localhost:1527/Empleados";
    public String BD = "Empleados";
    public Connection conex;
    String consulta = "";

    public Connection conectar() {
        conex = null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conex = DriverManager.getConnection(url, user, password);
            PreparedStatement ps;
            Statement smt;
            ResultSet rs;
            smt = conex.createStatement();
            rs = smt.executeQuery("select * from employees ");
            if (conex != null) {
                JOptionPane.showMessageDialog(null, "Conexion establecida");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al conectarse" + ex);
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return conex;
    }

    public void Consulta(String identificacion, String nombre, String apellido, String email,
            String telefono, String fechacontratacion, String salario, String comision, String trabajo,
             String gerente, String departamento) {
        Connection con = conectar();
        try {
            consulta = "insert into employees values(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement prepStmt = con.prepareStatement(consulta);
            prepStmt.setString(1, nombre);
            prepStmt.setString(2, apellido);
            prepStmt.setString(3, email);
            prepStmt.setString(4, telefono);
            prepStmt.setString(5, fechacontratacion);
            prepStmt.setString(6, salario);
            prepStmt.setString(7, comision);
            prepStmt.setString(8, trabajo);
            prepStmt.setString(9, gerente);
            prepStmt.setString(10, departamento); 
            prepStmt.setString(11, identificacion);
            prepStmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro Ingresado", "Sistema", 1);
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
    }
}

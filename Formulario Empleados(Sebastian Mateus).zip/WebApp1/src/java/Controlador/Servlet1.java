
package Controlador;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Modelo.Conectar;


@WebServlet(name = "Servlet1", urlPatterns = {"/Servlet1"})
public class Servlet1 extends HttpServlet {
    Conectar conect= new Conectar();
    

   public String nombre;
   public String apellido;
   public String identificacion;
   public String email;
   public String telefono;
   public String fechacontratacion;
   public String salario;
   public String comision;
   public String trabajo;
   public String gerente;
   public String departamento;
   
   public String getNombre() {
        return nombre;
    }
   public String getApellido(){
       return apellido;
   }
   public String getIdentificacion(){
       return identificacion;
   }
   public String getEmail(){
       return email;
   }
   public String getTelefono(){
       return telefono;
   }
   public String getFechacontratacion(){
       return fechacontratacion;
   }
   public String getSalario(){
       return salario;
   }
   public String getComision(){
       return comision;
   }
   public String getTrabajo(){
       return trabajo;
   }
   public String getGerente(){
       return gerente;
   }
   public String getDepartamento(){
       return departamento;
   }
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Conectar conect= new Conectar();
        
        nombre= request.getParameter("Nombre");
        apellido= request.getParameter("Apellido");
        identificacion= request.getParameter("Identificacion");
        email= request.getParameter("Email");
        telefono= request.getParameter("Telefono");
        fechacontratacion= request.getParameter("Fecha de Contratacion");
        salario= request.getParameter("Salario");
        comision= request.getParameter("Comision");
        trabajo= request.getParameter("Trabajo");
        gerente= request.getParameter("Gerente");
        departamento= request.getParameter("Departamento");  
        
        conect.Consulta(identificacion,nombre, apellido,email, telefono, fechacontratacion, salario, comision, trabajo, gerente, departamento);
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

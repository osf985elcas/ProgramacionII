
package Modelo.Conexion;
import java.sql.*;
import javax.swing.JOptionPane;


public class Conexion {
    private static Connection conex;
    private static final String driver="com.mysql.jdbc.Driver";
    private static final String user="root";
    private static final String password="";
    private static final String url="jdbc:mysql://localhost:3306/empresa2";
    
    public Conexion(){
        conectar();
    }
    public Connection getConnection(){
        conectar();
        return conex;
    }
    public void conectar(){
    conex = null;
        try {
            Class.forName(driver);
            conex = DriverManager.getConnection(url, user, password);
            if(conex != null){
                JOptionPane.showMessageDialog(null,"Conexion Establecida");
            }
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null,"Error al conectar "+e);
        }
    }
    public void desconectar (){
        conex = null;
        if (conex == null){
            JOptionPane.showMessageDialog(null,"Conexion Finalizada");
        }
    }
}

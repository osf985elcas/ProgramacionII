/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio.control;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class controlador {
    public String id;
    public String nom;
    public controlador(){
        
    }
    public void capturar(JTextField campo1, JTextField campo2){
        String id1=campo1.getText();
        id=id1;
        String nom2=campo2.getText();
        nom=nom2;
    }
    public void limpiarTabla(JTable table){
            DefaultTableModel modelo=(DefaultTableModel) table.getModel();
            int filas=table.getRowCount();
            for (int i = 1;i<=filas; i++) {
                modelo.removeRow(0);
}
} 
}


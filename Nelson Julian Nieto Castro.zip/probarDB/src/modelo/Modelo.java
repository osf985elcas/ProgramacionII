
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import vista.conexion;
public class Modelo {
    
DefaultTableModel model;
ResultSet rs = null;
String Consulta="";
private static Connection conex;
public String driver = "com.mysql.jdbc.Driver";
private static final String user = "oscar";
private static final String password = "hola1234";
private static final String url = "jdbc:mysql://192.168.64.2:3306/company";

public Connection getConnection (){
            return conex;
            
        }

        public void conectar(){
            conex=null;
    try {
	Class.forName(driver);		
	conex= DriverManager.getConnection(url,user,password);
	if(conex!=null){
	    JOptionPane.showMessageDialog(null,"Conexion establecida");
        }
       } catch (ClassNotFoundException | SQLException e){
	System.out.println("Error al conectar" + e);
       }
        }
        public void desconectar (){
            conex=null;
                if (conex==null){
                    JOptionPane.showMessageDialog(null,"Conexion finalizada");
                }
                }
        public void traerTabla(JTable tabla1){
        Consulta = "SELECT * FROM REGIONS";
        String[] titulos = {"ID", "NOMBRE"};
        try {
            model = new DefaultTableModel(null, titulos);
            rs = conex.createStatement().executeQuery(Consulta);
            String[] fila = new String[2];
            while (rs.next()) {
                fila[0] = rs.getString("region_id");
                fila[1] = rs.getString("region_name");
                model.addRow(fila);
            }

            tabla1.setModel(model);
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }   
  }
  public void Enviar(String id,String nom){
     
        try {
            Consulta = "INSERT INTO REGIONS VALUES (?,?);";
            JOptionPane.showMessageDialog(null, "Registro Ingresado", "Sistema", 1);
            PreparedStatement prepStmt=conex.prepareStatement(Consulta);
            prepStmt.setString(1, id);
            prepStmt.setString(2, nom);
            prepStmt.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        }
  }
        


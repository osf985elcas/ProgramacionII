
package controlador;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class controlador {
    public String id;
    public String nombre;
    
    public void capturar(JTextField campo1, JTextField campo2){
        String identify=campo1.getText();
        id=identify;
        String name=campo2.getText();
        nombre=name;
    }
    
    public void limpiarTabla(JTable table){
        try {
            DefaultTableModel modelo=(DefaultTableModel) table.getModel();
            int filas=table.getRowCount();
            for (int i = 0;i<=filas; i++) {
                modelo.removeRow(0);
}
} catch (Exception e) {
//JOptionPane.showMessageDialog(null, "Error al limpiar la tabla.");
}
}
    
}

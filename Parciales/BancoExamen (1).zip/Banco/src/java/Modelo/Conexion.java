
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class Conexion {

    Connection cn;
    String url = "jdbc:mysql://localhost:3306/examen";
    String drv = "com.mysql.jdbc.Driver";
    String usu = "root";
    String pass = "";
    PreparedStatement pstm = null;
    ResultSet rs = null;
    String sql = "";
    public Connection getConnection() {

        try {
            Class.forName(drv);
            cn = DriverManager.getConnection(url, usu, pass);
            pstm = cn.prepareStatement(sql);
            System.out.println("Conexion exitosa");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de conexion: " + e);
        }
        return cn;
    }

    public ResultSet getDatos(String com){
        try {
            this.getConnection();
            rs = pstm.executeQuery(com);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error: "+e);
        }
        return rs;
    }


}


package Controlador;

/**
 *
 * @author Manuel S.
 */
public class CuentaBancaria {
    
    public CuentaBancaria(){
        
    }
}

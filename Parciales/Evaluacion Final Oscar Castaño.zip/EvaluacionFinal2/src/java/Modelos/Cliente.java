/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class Cliente {
  public int Cedula; 
  public String Apellido;
  public String Nombre;
}

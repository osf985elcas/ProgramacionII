/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class Prestamo {
    public int NumeroCuenta;
    public int Cedula;
    public Double ValorPrestamo;
    public int TiempoPago;
    public int ValorInteres;
    public String FechaInicioPrestamo;
    public String FechaFinPrestamo;  
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import DAO.DAOConsignacion;
import Modelos.Consignacion;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author oscarfelipecastanomartinez
 */
@WebServlet(name = "ctrlConsignacion", urlPatterns = {"/ctrlConsignacion"})
public class ctrlConsignacion extends HttpServlet {

    String Consignacion = "Consignacion.jsp";
    Consignacion Consig = new Consignacion();
    DAOConsignacion DaoConsig = new DAOConsignacion();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String action = request.getParameter("accion");
        String acceso = "";
        if (action.equalsIgnoreCase("Insertar")) {
            int NumeroCuenta = Integer.parseInt(request.getParameter("NumeroCuenta"));
            String FechaApertura = request.getParameter("Fecha");
            Double ValorConsignacion = Double.parseDouble(request.getParameter("ValorConsignacion"));
            Consig.NumeroCuenta = NumeroCuenta;
            Consig.Fecha = FechaApertura;
            Consig.ValorConsignacion = ValorConsignacion;
            DaoConsig.RegistrarConsignacion(Consig);
            acceso = Consignacion;
        }
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import DAO.DAOPrestamo;
import Modelos.CuentaBancaria;
import Modelos.Prestamo;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author oscarfelipecastanomartinez
 */
@WebServlet(name = "ctrlPrestamo", urlPatterns = {"/ctrlPrestamo"})
public class ctrlPrestamo extends HttpServlet {

    String Prestamo = "Prestamos.jsp";
    Prestamo Pres = new Prestamo();
    DAOPrestamo daoPres = new DAOPrestamo();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String action = request.getParameter("accion");
        String acceso = "";
        if (action.equalsIgnoreCase("Registrar")) {
            int NumeroCuenta = Integer.parseInt(request.getParameter("NumeroCuenta"));
            int TiempoPago = Integer.parseInt(request.getParameter("TiempoPago"));
            Double ValorPrestamo = Double.parseDouble(request.getParameter("ValorPrestamo"));
            int ValorInteres = Integer.parseInt(request.getParameter("ValorInteres"));
            String FechaInicioPrestamo = request.getParameter("FechaInicioPrestamo");
            String FechaFinPrestamo = request.getParameter("FechaFinPrestamo");
            Pres.NumeroCuenta = NumeroCuenta;
            Pres.TiempoPago=TiempoPago;
            Pres.ValorPrestamo = ValorPrestamo;
            Pres.ValorInteres = ValorInteres;
            Pres.FechaInicioPrestamo = FechaInicioPrestamo;
            Pres.FechaFinPrestamo=FechaFinPrestamo;
            daoPres.pedirPrestamo(Pres);
            acceso = Prestamo;
        } else if (action.equalsIgnoreCase("Pagar")) {
            request.setAttribute("id", request.getParameter("ncuenta"));
            acceso = Prestamo;
        } else if (action.equalsIgnoreCase("RegistrarFecha")) {
            int numeroCuenta = Integer.parseInt(request.getParameter("NumeroCuenta"));
            String FechaFinPrestamo = request.getParameter("FechaFinPrestamo");
            Pres.NumeroCuenta = numeroCuenta;
            Pres.FechaFinPrestamo = FechaFinPrestamo;
            daoPres.pagarPrestamo(Pres);
            acceso = Prestamo;
        }
        RequestDispatcher vista = request.getRequestDispatcher(acceso);
        vista.forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

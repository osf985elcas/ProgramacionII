/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;


import DAO.DAOCuentaBancaria;
import Modelos.CuentaBancaria;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author oscarfelipecastanomartinez
 */
@WebServlet(name = "ctrlCuentaBancaria", urlPatterns = {"/ctrlCuentaBancaria"})
public class ctrlCuentaBancaria extends HttpServlet {
     String CuentaBancaria="CuentaBancaria.jsp";
     CuentaBancaria CunB=new CuentaBancaria();
     DAOCuentaBancaria DaoCunb=new DAOCuentaBancaria();
        
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);  
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            processRequest(request, response);      
            String action = request.getParameter("accion");
            String acceso="";
            if(action.equalsIgnoreCase("Aperturar")){
            int NumeroCuenta = Integer.parseInt(request.getParameter("NumeroCuenta"));   
            int Cedula = Integer.parseInt(request.getParameter("Cedula"));
            String FechaApertura = request.getParameter("FechaApertura");
            Double Monto= Double.parseDouble(request.getParameter("Monto"));
            CunB.NumeroCuenta=NumeroCuenta;
            CunB.Cedula=Cedula;
            CunB.FechaApertura=FechaApertura;
            CunB.Monto=Monto;
            DaoCunb.AperturarCuenta(CunB);
            acceso=CuentaBancaria;
            }else if (action.equalsIgnoreCase("Eliminar")) {
            int numeroCun=Integer.parseInt(request.getParameter("ncuenta"));
            CunB.NumeroCuenta=numeroCun;
            DaoCunb.DesactivarCuenta(numeroCun);
            acceso=CuentaBancaria;
            }else if (action.equalsIgnoreCase("Modificar")) {
             request.setAttribute("id",request.getParameter("ncuenta"));
             acceso=CuentaBancaria;
             }
            else if (action.equalsIgnoreCase("Actualizar")) {
            int NumeroCuenta = Integer.parseInt(request.getParameter("NumeroCuenta"));   
            int Cedula = Integer.parseInt(request.getParameter("Cedula"));
            String FechaApertura = request.getParameter("FechaApertura");
            Double Monto= Double.parseDouble(request.getParameter("Monto"));
            CunB.NumeroCuenta=NumeroCuenta;
            CunB.Cedula=Cedula;
            CunB.FechaApertura=FechaApertura;
            CunB.Monto=Monto;
            DaoCunb.ActualizarCuenta(CunB);
            acceso=CuentaBancaria;
            }
            RequestDispatcher vista = request.getRequestDispatcher(acceso);
            vista.forward(request, response);
    }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

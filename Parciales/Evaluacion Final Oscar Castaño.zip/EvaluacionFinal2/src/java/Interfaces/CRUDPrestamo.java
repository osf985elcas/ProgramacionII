/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Modelos.Prestamo;
import java.util.List;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public interface CRUDPrestamo {
     public List mostrarjcombobox1();
     public List listar();
     public Prestamo list(int NumeroCuenta);
     public Double pedirPrestamo(Prestamo pres);
     public Double pagarPrestamo(Prestamo pres);
}

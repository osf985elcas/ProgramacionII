/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Modelos.CuentaBancaria;
import java.util.List;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public interface CRUDCuentaBancaria {
    public List mostrarjcombobox1();
    public List listar();
    public CuentaBancaria list(int NumeroCuenta);
    public String AperturarCuenta(CuentaBancaria cunB);
    public String ActualizarCuenta(CuentaBancaria cunB);
    public String DesactivarCuenta(int NumeroCuenta);
}

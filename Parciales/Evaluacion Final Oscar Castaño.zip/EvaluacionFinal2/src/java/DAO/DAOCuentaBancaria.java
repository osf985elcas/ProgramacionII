/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Interfaces.CRUDCuentaBancaria;
import Modelos.Cliente;
import Modelos.CuentaBancaria;
import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class DAOCuentaBancaria implements CRUDCuentaBancaria {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    CuentaBancaria cunb2=new CuentaBancaria();

    @Override
    public List mostrarjcombobox1() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        try {
            String consulta = "SELECT * FROM Cliente;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.Cedula = rs.getInt(1);
                cli.Apellido = rs.getString(2);
                cli.Nombre = rs.getString(3);
                clientes.add(cli);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return clientes;
    }

    @Override
    public List listar() {
        ArrayList<CuentaBancaria> cuentasBancarias = new ArrayList<>();
        try {
            String consulta4 = "SELECT  NumeroCuenta,CuentaBancaria.Cedula, Cliente.Apellido, \n"
                    + "Cliente.Nombre, FechaApertura, Monto \n"
                    + "FROM CuentaBancaria INNER JOIN Cliente \n"
                    + "ON CuentaBancaria.Cedula=Cliente.Cedula ;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                CuentaBancaria cunB = new CuentaBancaria();
                cunB.NumeroCuenta = rs.getInt(1);
                cunB.Cedula = rs.getInt(2);
                cunB.Nombre=rs.getString(3);
                cunB.Apellido=rs.getString(4);
                cunB.FechaApertura = rs.getString(5);
                cunB.Monto = rs.getDouble(6);
                cuentasBancarias.add(cunB);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return cuentasBancarias;
    }

    @Override
    public CuentaBancaria list(int NumeroCuenta) {
         try {
            String consulta4 = "SELECT * FROM CuentaBancaria WHERE NumeroCuenta=?;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            ps.setInt(1, NumeroCuenta);
            rs=ps.executeQuery();
            while (rs.next()) {
                cunb2.NumeroCuenta=rs.getInt("NumeroCuenta");
                cunb2.Cedula=rs.getInt("Cedula");
                cunb2.FechaApertura=rs.getString("FechaApertura");
                cunb2.Monto=rs.getInt("Monto");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return cunb2;
    }

    @Override
    public String AperturarCuenta(CuentaBancaria cunB) {
        try{
        con = cn.getConnection();
            String s = "INSERT INTO CuentaBancaria VALUES (?,?,?,?);";
            ps = con.prepareStatement(s);
            ps.setInt(1, cunB.NumeroCuenta);
            ps.setInt(2, cunB.Cedula);
            System.out.println(cunB.NumeroCuenta);            
            ps.setString(3, cunB.FechaApertura);
            ps.setDouble(4, cunB.Monto);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return "Cuenta Aperturada";        
    }

    @Override
    public String ActualizarCuenta(CuentaBancaria cunB) {
        try {
            con = cn.getConnection();
            String s = "UPDATE CuentaBancaria SET Cedula=?,FechaApertura=?,Monto=? WHERE NumeroCuenta=?;";
            ps = con.prepareStatement(s);
            ps.setInt(1, cunB.Cedula);
            ps.setString(2, cunB.FechaApertura);
            ps.setDouble(3, cunB.Monto);
            ps.setInt(4, cunB.NumeroCuenta);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return "Actualizado";
    }

    @Override
    public String DesactivarCuenta(int NumeroCuenta) {
                try {
            con = cn.getConnection();
            String consulta = "DELETE FROM CuentaBancaria WHERE NumeroCuenta=?;";
            ps = con.prepareStatement(consulta);
            ps.setInt(1, NumeroCuenta);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);

        }
        return "Cuenta Desactivada";
    }

}

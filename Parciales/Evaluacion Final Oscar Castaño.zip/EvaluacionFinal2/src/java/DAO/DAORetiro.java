/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Interfaces.CRUDRetiro;
import Modelos.CuentaBancaria;
import Modelos.Retiro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class DAORetiro implements CRUDRetiro {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Retiro retir2 = new Retiro();

    @Override
    public double RegistrarRetiro(Retiro retir) {
         try{
        con = cn.getConnection();
            String s = "INSERT INTO Retiro VALUES (?,?,?);";
            ps = con.prepareStatement(s);
            ps.setInt(1, retir.NumeroCuenta);      
            ps.setString(2, retir.Fecha);
            ps.setDouble(3, retir.ValorRetiro);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return retir.ValorRetiro;         
    }

    @Override
    public List listar() {
        ArrayList<Retiro> retiros = new ArrayList<>();
        try {
            String consulta4 = "SELECT Retiro.NumeroCuenta,CuentaBancaria.Cedula,Fecha,ValorRetiro\n"
                    + "FROM Retiro INNER JOIN CuentaBancaria ON "
                    + "CuentaBancaria.NumeroCuenta=Retiro.NumeroCuenta;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                Retiro retir = new Retiro();
                retir.NumeroCuenta = rs.getInt(1);
                retir.Cedula = rs.getInt(2);
                retir.Fecha = rs.getString(3);
                retir.ValorRetiro = rs.getDouble(4);
                retiros.add(retir);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return retiros;
    }

    @Override
    public List mostrarjcombobox1() {
        ArrayList<CuentaBancaria> cuentasBancarias = new ArrayList<>();
        try {
            String consulta4 = "SELECT * FROM CuentaBancaria";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                CuentaBancaria cunB = new CuentaBancaria();
                cunB.NumeroCuenta = rs.getInt(1);
                cunB.Cedula = rs.getInt(2);
                cuentasBancarias.add(cunB);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return cuentasBancarias;
    }
}

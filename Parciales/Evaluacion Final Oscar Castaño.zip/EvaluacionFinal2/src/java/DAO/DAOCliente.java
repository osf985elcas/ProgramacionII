/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
import Conexion.Conexion;
import Interfaces.CRUDCliente;
import Modelos.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
/**
 *
 * @author oscarfelipecastanomartinez
 */
public class DAOCliente implements CRUDCliente{
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Cliente cli = new Cliente();


    @Override
    public String pedirAsesoramiento(Cliente cli) {
    try {
            con = cn.getConnection();
            String s = "INSERT INTO Cliente VALUES (?,?,?);";
            ps = con.prepareStatement(s);
            ps.setInt(1, cli.Cedula);
            ps.setString(2, cli.Apellido);
            ps.setString(3, cli.Nombre);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return "Registro Ingresado";
      }

    @Override
    public List Cliente() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        try {
            String consulta4 = "SELECT * FROM Cliente ;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                Cliente cli2 = new Cliente();
                cli2.Cedula = rs.getInt(1);
                cli2.Apellido=rs.getString(2);
                cli2.Nombre=rs.getString(3);
                clientes.add(cli2);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return clientes;
    }
}

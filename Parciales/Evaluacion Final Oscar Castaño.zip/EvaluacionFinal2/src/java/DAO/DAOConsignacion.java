/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Interfaces.CRUDConsignacion;
import Modelos.Consignacion;
import Modelos.CuentaBancaria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class DAOConsignacion implements CRUDConsignacion {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Consignacion consig2 = new Consignacion();

    @Override
    public double RegistrarConsignacion(Consignacion consig) {
         try{
        con = cn.getConnection();
            String s = "INSERT INTO Consignacion VALUES (?,?,?);";
            ps = con.prepareStatement(s);
            ps.setInt(1, consig.NumeroCuenta);      
            ps.setString(2, consig.Fecha);
            ps.setDouble(3, consig.ValorConsignacion);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return consig.ValorConsignacion;         
    }

    @Override
    public List listar() {
        ArrayList<Consignacion> consignaciones = new ArrayList<>();
        try {
            String consulta4 = "SELECT Consignacion.NumeroCuenta,CuentaBancaria.Cedula,Fecha,ValorConsignacion\n"
                    + "FROM Consignacion INNER JOIN CuentaBancaria ON "
                    + "CuentaBancaria.NumeroCuenta=Consignacion.NumeroCuenta;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                Consignacion consig = new Consignacion();
                consig.NumeroCuenta = rs.getInt(1);
                consig.Cedula = rs.getInt(2);
                consig.Fecha = rs.getString(3);
                consig.ValorConsignacion = rs.getDouble(4);
                consignaciones.add(consig);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return consignaciones;
    }

    @Override
    public List mostrarjcombobox1() {
        ArrayList<CuentaBancaria> cuentasBancarias = new ArrayList<>();
        try {
            String consulta4 = "SELECT * FROM CuentaBancaria";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                CuentaBancaria cunB = new CuentaBancaria();
                cunB.NumeroCuenta = rs.getInt(1);
                cunB.Cedula = rs.getInt(2);
                cuentasBancarias.add(cunB);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return cuentasBancarias;
    }
}

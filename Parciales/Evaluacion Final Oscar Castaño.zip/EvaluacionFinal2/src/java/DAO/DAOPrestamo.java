/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Interfaces.CRUDPrestamo;
import Modelos.CuentaBancaria;
import Modelos.Prestamo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class DAOPrestamo implements CRUDPrestamo {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Prestamo pres2 = new Prestamo();

    @Override
    public Double pedirPrestamo(Prestamo pres) {
        try {
            con = cn.getConnection();
            String s = "INSERT INTO Prestamo VALUES (?,?,?,?,?,?);";
            ps = con.prepareStatement(s);
            ps.setInt(1, pres.NumeroCuenta);
            ps.setDouble(2, pres.ValorPrestamo);
            ps.setInt(3, pres.TiempoPago);
            ps.setInt(4, pres.ValorInteres);
            ps.setString(5, pres.FechaInicioPrestamo);
            ps.setString(6, pres.FechaFinPrestamo);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return pres.ValorPrestamo;
    }

    @Override
    public Double pagarPrestamo(Prestamo pres) {
       try {
            con = cn.getConnection();
            String s = "UPDATE Prestamo SET FechaFinPrestamo=? WHERE NumeroCuenta=?;";
            ps = con.prepareStatement(s);
            ps.setString(1, pres.FechaFinPrestamo);
            ps.setInt(2, pres.NumeroCuenta);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return pres.ValorPrestamo;
    }

    @Override
    public List mostrarjcombobox1() {
        ArrayList<CuentaBancaria> cuentasBancarias = new ArrayList<>();
        try {
            String consulta4 = "SELECT * FROM CuentaBancaria";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                CuentaBancaria cunB = new CuentaBancaria();
                cunB.NumeroCuenta = rs.getInt(1);
                cunB.Cedula = rs.getInt(2);
                cuentasBancarias.add(cunB);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return cuentasBancarias;

    }

    @Override
    public List listar() {
        ArrayList<Prestamo> Prestamos = new ArrayList<>();
        try {
            String consulta4 = "SELECT Prestamo.NumeroCuenta,CuentaBancaria.Cedula,ValorPrestamo,TiempoPago,ValorInteres,\n"
                    + "FechaInicioPrestamo,FechaFinPrestamo FROM Prestamo INNER JOIN CuentaBancaria \n"
                    + "ON CuentaBancaria.NumeroCuenta=Prestamo.NumeroCuenta;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                Prestamo pres = new Prestamo();
                pres.NumeroCuenta = rs.getInt(1);
                pres.Cedula = rs.getInt(2);
                pres.ValorPrestamo = rs.getDouble(3);
                pres.TiempoPago = rs.getInt(4);
                pres.ValorInteres = rs.getInt(5);
                pres.FechaInicioPrestamo = rs.getString(6);
                pres.FechaFinPrestamo=rs.getString(7);
                Prestamos.add(pres);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return Prestamos;
    }

    @Override
    public Prestamo list(int NumeroCuenta){
                try {
            String consulta4 = "SELECT NumeroCuenta,FechaFinPrestamo FROM Prestamo WHERE NumeroCuenta=?;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            ps.setInt(1, NumeroCuenta);
            rs=ps.executeQuery();
            while (rs.next()) {
                pres2.NumeroCuenta=rs.getInt("NumeroCuenta");
                pres2.FechaFinPrestamo=rs.getString("FechaFinPrestamo");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return pres2;
    }

}

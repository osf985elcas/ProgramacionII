package Modelo;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Controlador.*;
import javax.swing.JOptionPane;

public class Conectar {

    public String user = "sebastian";
    public String password = "1234";
    public String url = "jdbc:derby://localhost:1527/Banco";   
    public Connection conex;
    String consulta = "";

    public Connection conectar() {
        conex = null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conex = DriverManager.getConnection(url, user, password);
            PreparedStatement ps;
            Statement smt;
            ResultSet rs;
            smt = conex.createStatement();            
        } catch (SQLException ex) {
            
        } catch (ClassNotFoundException ex) {
           
        }
        return conex;
    }

    public void ConsultaClientes(String cedula, String nombre, String apellido) {
        Connection con = conectar();
        try {
            consulta = "insert into clientes values(?,?,?)";
            PreparedStatement ps = con.prepareStatement(consulta);
            ps.setString(1, cedula);
            ps.setString(2, nombre);
            ps.setString(3, apellido);            
            ps.executeUpdate();            
        } catch (SQLException err) {
            
        }
    }
    public void ConsultaConsignaciones(int numeroconsignacion,int numerocuenta, String fecha,double valorconsignacion) {
        Connection con = conectar();
        try {
            consulta = "insert into consignaciones values(?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(consulta);
            ps.setInt(1, numeroconsignacion);
            ps.setInt(2, numerocuenta);
            ps.setString(3, fecha);
            ps.setDouble(4, valorconsignacion);
            ps.executeUpdate();           
        } catch (SQLException err) {
            
        }
    }
    public void ConsultaCuentasBancarias(int numerocuenta, int cedula, String fechaapertura
            ,double monto) {
        Connection con = conectar();
        try {
            consulta = "insert into cuentasbancarias values(?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(consulta);
            ps.setInt(1, numerocuenta);
            ps.setInt(2, cedula);
            ps.setString(3, fechaapertura);
            ps.setDouble(4, monto);
            ps.executeUpdate();           
        } catch (SQLException err) {
            
        }
    }
    public void ConsultaPrestamos(int numeroprestamo,int numerocuenta, double valorprestamo,int tiempopago
    ,int valorinteres,String fechainicioprestamo,String fechafinprestamo) {
        Connection con = conectar();
        try {
            consulta = "insert into prestamos values(?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(consulta);
            ps.setInt(1, numeroprestamo);
            ps.setInt(2, numerocuenta);
            ps.setDouble(3, valorprestamo);
            ps.setInt(4, tiempopago); 
            ps.setInt(5, valorinteres);
            ps.setString(6, fechainicioprestamo);
            ps.setString(7, fechafinprestamo);
            ps.executeUpdate();           
        } catch (SQLException err) {
           
        }
    }
    public void ConsultaRetiros(int numeroretiro,int numerocuenta, String fecha, double valorretiro) {
        Connection con = conectar();
        try {
            consulta = "insert into retiros values(?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(consulta);
            ps.setInt(1, numeroretiro);
            ps.setInt(2, numerocuenta);
            ps.setString(3, fecha);
            ps.setDouble(4, valorretiro);            
            ps.executeUpdate();            
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err);
        }
    }
    public void Actualizar(int cedula,String fechaapertura,double monto, int numerocuenta){
        ServletActualizar sa= new ServletActualizar();
        Connection con = conectar();
        try {     
            String consulta1 = "update cuentasbancarias set Cedula=?, FechaApertura=?, Monto=? where NumeroCuenta=? ";
            PreparedStatement ps = con.prepareStatement(consulta1);
            ps.setInt(1, cedula);
            ps.setString(2, fechaapertura);
            ps.setDouble(3, monto);
            ps.setInt(4, numerocuenta);
            ps.executeUpdate();                  
        } catch (SQLException err) {
            
        }
    }
    public void DesactivarCuemta(int numerocuenta){
        Connection con = conectar();
        try {     
            String consulta2 = "delete from cuentasbancarias where NumeroCuenta=?";
            PreparedStatement ps = con.prepareStatement(consulta2);            
            ps.setInt(1, numerocuenta);
            ps.executeUpdate();           
        } catch (SQLException err) {
            
        }   
    }
    public void Pagar(String fechafinprestamo, int numerocuenta){
         Connection con = conectar();
        try {     
            String consulta1 = "update prestamos set  FechaFinPrestamo=?  where NumeroCuenta=? ";
            PreparedStatement ps = con.prepareStatement(consulta1);
            ps.setString(1,fechafinprestamo);
            ps.setInt(2, numerocuenta);
            ps.executeUpdate();           
        } catch (SQLException err) {
            
        }   
    }
}


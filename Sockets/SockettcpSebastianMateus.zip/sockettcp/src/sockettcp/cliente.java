/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockettcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class cliente {
    public static void main(String[] args) {
        final String HOST="10.51.19.118";
        final int puerto=5000;
         DataInputStream in;
        DataOutputStream out;
        try {
              Socket sc=new Socket(HOST, puerto);
              in= new DataInputStream(sc.getInputStream());
              out= new DataOutputStream(sc.getOutputStream());
              out.writeUTF("Hola perros desde el server");
              String mensaje=in.readUTF();
              System.out.println(mensaje);
              sc.close();
        } catch (IOException ex) {
            Logger.getLogger(cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}

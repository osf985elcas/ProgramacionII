package socketudp;

import java.net.*;
import java.io.*;

public class SocketUDP {
 public static void main(String argv[]) {

DatagramSocket socket;
 boolean fin = false;

try {
 socket = new DatagramSocket(6000);

byte[] mensaje_bytes = new byte[256];
 String mensaje ="";
 mensaje = new String(mensaje_bytes);
 String mensajeComp ="";

DatagramPacket paquete = new DatagramPacket(mensaje_bytes,256);
 DatagramPacket envpaquete = new DatagramPacket(mensaje_bytes,256);

int puerto;
 InetAddress address;
 byte[] mensaje2_bytes = new byte[256];

 do {

 socket.receive(paquete);

 mensaje = new String(mensaje_bytes).trim();
 
 System.out.println(mensaje);

 puerto = paquete.getPort();
 address = paquete.getAddress();

 if (mensaje.startsWith("fin")) {
 mensajeComp="Bye cliente";
 }

 if (mensaje.startsWith("hola")) {
 mensajeComp="hola cliente";
 }
 mensaje2_bytes = mensajeComp.getBytes();

//Preparamos el paquete que queremos enviar
 envpaquete = new DatagramPacket(mensaje2_bytes,mensajeComp.length(),address,puerto);

// realizamos el envio
 socket.send(envpaquete);

} while (1>0);
 }
 catch (Exception e) {
 System.err.println(e.getMessage());
 System.exit(1);
 }
 }
}
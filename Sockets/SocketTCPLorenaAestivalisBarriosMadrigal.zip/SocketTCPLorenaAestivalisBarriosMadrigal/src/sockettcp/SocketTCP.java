/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockettcp;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Karen Noemi
 */
public class SocketTCP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        ServerSocket servidor =null;
        Socket sc=null;
        DataInputStream in;
        DataOutputStream out;
        final int PUERTO=5000;
        
        try {
            servidor =new ServerSocket(PUERTO);
            System.out.println("Servidor iniciado");
            
            while(true){
                sc= servidor.accept();
                
                in =new DataInputStream(sc.getInputStream());
                out =new DataOutputStream(sc.getOutputStream());
                
                String mensaje = in.readUTF(); 
                
                System.out.println("Hola mundo desde el servidor!");
                sc.close();
            }
        } catch (IOException ex) {
            Logger.getLogger(SocketTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class Departamento {
 private String departament_id;
 private String departament_name;

    /**
     * @return the departament_id
     */
    public String getDepartament_id() {
        return departament_id;
    }

    /**
     * @param departament_id the departament_id to set
     */
    public void setDepartament_id(String departament_id) {
        this.departament_id = departament_id;
    }

    /**
     * @return the departament_name
     */
    public String getDepartament_name() {
        return departament_name;
    }

    /**
     * @param departament_name the departament_name to set
     */
    public void setDepartament_name(String departament_name) {
        this.departament_name = departament_name;
    }
    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
/**
 *
 * @author oscarfelipecastanomartinez
 */
public class Empleados {

    private String employee_id;
    private String first_name;
    private String last_name;
    private String e_mail;
    private String phone_number;
    private String hire_date;
    private String job_id;
    private String salary;
    private String commission_pct;
    private String manager_id;
    private String manager_name;
    private String job_title;
    private String department_title; 
    private String department_id;


    /**
     * @return the employee_id
     */
    public String getEmployee_id() {
        return employee_id;
    }

    /**
     * @param employee_id the employee_id to set
     */
    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    /**
     * @return the first_name
     */
    public String getFirst_name() {
        return first_name;
    }

    /**
     * @param first_name the first_name to set
     */
    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    /**
     * @return the last_name
     */
    public String getLast_name() {
        return last_name;
    }

    /**
     * @param last_name the last_name to set
     */
    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    /**
     * @return the e_mail
     */
    public String getE_mail() {
        return e_mail;
    }

    /**
     * @param e_mail the e_mail to set
     */
    public void setE_mail(String e_mail) {
        this.e_mail = e_mail;
    }

    /**
     * @return the phone_number
     */
    public String getPhone_number() {
        return phone_number;
    }

    /**
     * @param phone_number the phone_number to set
     */
    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    /**
     * @return the hire_date
     */
    public String getHire_date() {
        return hire_date;
    }

    /**
     * @param hire_date the hire_date to set
     */
    public void setHire_date(String hire_date) {
        this.hire_date = hire_date;
    }

    /**
     * @return the job_id
     */
    public String getJob_id() {
        return job_id;
    }

    /**
     * @param job_id the job_id to set
     */
    public void setJob_id(String job_id) {
        this.job_id = job_id;
    }

    /**
     * @return the salary
     */
    public String getSalary() {
        return salary;
    }

    /**
     * @param salary the salary to set
     */
    public void setSalary(String salary) {
        this.salary = salary;
    }

    /**
     * @return the commission_pct
     */
    public String getCommission_pct() {
        return commission_pct;
    }

    /**
     * @param commission_pct the commission_pct to set
     */
    public void setCommission_pct(String commission_pct) {
        this.commission_pct = commission_pct;
    }

    /**
     * @return the manager_id
     */
    public String getManager_id() {
        return manager_id;
    }

    /**
     * @param manager_id the manager_id to set
     */
    public void setManager_id(String manager_id) {
        this.manager_id = manager_id;
    }

    /**
     * @return the department_id
     */
    public String getDepartment_id() {
        return department_id;
    }

    /**
     * @param department_id the department_id to set
     */
    public void setDepartment_id(String department_id) {
        this.department_id = department_id;
    }

    /**
     * @return the manager_name
     */
    public String getManager_name() {
        return manager_name;
    }

    /**
     * @param manager_name the manager_name to set
     */
    public void setManager_name(String manager_name) {
        this.manager_name = manager_name;
    }

    /**
     * @return the job_title
     */
    public String getJob_title() {
        return job_title;
    }

    /**
     * @param job_title the job_title to set
     */
    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    /**
     * @return the department_title
     */
    public String getDepartment_title() {
        return department_title;
    }

    /**
     * @param department_title the department_title to set
     */
    public void setDepartment_title(String department_title) {
        this.department_title = department_title;
    }

}

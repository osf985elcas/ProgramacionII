/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class Empleo {
    private String job_id;
    private String job_title;

    /**
     * @return the job_id
     */
    public Empleo(){
        
    }
    
    public String getJob_id() {
        return job_id;
    }

    /**
     * @param job_id the job_id to set
     */
    public void setJob_id(String job_id) {
        this.job_id = job_id;
    }

    /**
     * @return the job_title
     */
    public String getJob_title() {
        return job_title;
    }

    /**
     * @param job_title the job_title to set
     */
    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }
    
    
}

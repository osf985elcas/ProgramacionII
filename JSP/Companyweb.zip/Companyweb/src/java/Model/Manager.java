/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class Manager {
    private String manager_id;
    private String manager_name;
    
    public  Manager() {
    }
    /**
     * @return the manager_id
     */
    public String getManager_id() {
        return manager_id;
    }

    /**
     * @param manager_id the manager_id to set
     */
    public void setManager_id(String manager_id) {
        this.manager_id = manager_id;
    }

    /**
     * @return the manager_name
     */
    public String getManager_name() {
        return manager_name;
    }

    /**
     * @param manager_name the manager_name to set
     */
    public void setManager_name(String manager_name) {
        this.manager_name = manager_name;
    }
    
    
}

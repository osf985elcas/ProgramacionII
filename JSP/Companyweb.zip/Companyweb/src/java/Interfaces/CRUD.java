/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import Model.Empleados;
import java.util.List;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public interface CRUD {
    public List listar();
    public Empleados list(String id);
    public boolean add(Empleados emp);
    public boolean edit (Empleados emp);
    public boolean eliminar (String id);
    public List mostrarjcombo1();
    public List mostrarjcombo2();
    public List mostrarjcombo3();
    
            
}

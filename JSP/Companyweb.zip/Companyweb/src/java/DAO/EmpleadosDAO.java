/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conexion;
import Interfaces.CRUD;
import Model.Departamento;
import Model.Empleados;
import Model.Empleo;
import Model.Manager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author oscarfelipecastanomartinez
 */
public class EmpleadosDAO implements CRUD {

    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Empleados emp = new Empleados();

    @Override
    public List listar() {
        ArrayList<Empleados> empleados = new ArrayList<>();

        try {
            String consulta4 = "SELECT EMPLOYEES.employee_id,EMPLOYEES.first_name,EMPLOYEES.last_name,EMPLOYEES.e_mail,\n"
                    + "EMPLOYEES.phone_number,EMPLOYEES.hire_date,JOBS.job_title,\n"
                    + "EMPLOYEES.salary,EMPLOYEES.commission_pct,MANAGER.manager_name,DEPARTAMENTS.departament_name\n"
                    + " FROM EMPLOYEES INNER JOIN JOBS \n"
                    + " ON EMPLOYEES.job_Id=JOBS.job_id INNER JOIN MANAGER ON \n"
                    + " EMPLOYEES.manager_id=MANAGER.manager_id INNER JOIN DEPARTAMENTS\n"
                    + " ON EMPLOYEES.departament_id=DEPARTAMENTS.departament_id;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            rs = ps.executeQuery();
            while (rs.next()) {
                Empleados empleado = new Empleados();
                empleado.setEmployee_id(rs.getString("EMPLOYEES.employee_id"));
                empleado.setFirst_name(rs.getString("EMPLOYEES.first_name"));
                empleado.setLast_name(rs.getString("EMPLOYEES.last_name"));
                empleado.setE_mail(rs.getString("EMPLOYEES.e_mail"));
                empleado.setPhone_number(rs.getString("EMPLOYEES.phone_number"));
                empleado.setHire_date(rs.getString("EMPLOYEES.hire_date"));
                empleado.setJob_id(rs.getString("JOBS.job_title"));
                empleado.setCommission_pct(rs.getString("EMPLOYEES.commission_pct"));
                empleado.setSalary(rs.getString("EMPLOYEES.salary"));
                empleado.setManager_id(rs.getString("MANAGER.manager_name"));
                empleado.setDepartment_id(rs.getString("DEPARTAMENTS.departament_name"));
                empleados.add(empleado);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return empleados;
    }

    @Override
    public Empleados list(String id) {

        try {
            String consulta4 = "SELECT * FROM EMPLOYEES INNER JOIN JOBS \n"
                    + " ON EMPLOYEES.job_Id=JOBS.job_id INNER JOIN MANAGER ON \n"
                    + " EMPLOYEES.manager_id=MANAGER.manager_id INNER JOIN DEPARTAMENTS\n"
                    + " ON EMPLOYEES.departament_id=DEPARTAMENTS.departament_id WHERE employee_id=?;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta4);
            ps.setString(1, id);
            rs=ps.executeQuery();
            while (rs.next()) {
                emp.setEmployee_id(rs.getString("EMPLOYEES.employee_id"));
                emp.setFirst_name(rs.getString("EMPLOYEES.first_name"));
                emp.setLast_name(rs.getString("EMPLOYEES.last_name"));
                emp.setE_mail(rs.getString("EMPLOYEES.e_mail"));
                emp.setPhone_number(rs.getString("EMPLOYEES.phone_number"));
                emp.setHire_date(rs.getString("EMPLOYEES.hire_date"));
                emp.setJob_title(rs.getString("EMPLOYEES.job_id"));
                emp.setJob_id(rs.getString("JOBS.job_title"));
                emp.setCommission_pct(rs.getString("EMPLOYEES.commission_pct"));
                emp.setSalary(rs.getString("EMPLOYEES.salary"));
                emp.setManager_name(rs.getString("EMPLOYEES.manager_id"));
                emp.setManager_id(rs.getString("MANAGER.manager_name"));
                emp.setDepartment_title(rs.getString("EMPLOYEES.departament_id"));
                emp.setDepartment_id(rs.getString("DEPARTAMENTS.departament_name"));

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return emp;
    }

    @Override
    public boolean add(Empleados emp) {
        try {
            con = cn.getConnection();
            String s = "INSERT INTO EMPLOYEES VALUES (?,?,?,?,?,?,?,?,?,?,?);";
            ps = con.prepareStatement(s);
            ps.setString(1, emp.getEmployee_id());
            ps.setString(2, emp.getFirst_name());
            ps.setString(3, emp.getLast_name());
            ps.setString(4, emp.getE_mail());
            ps.setString(5, emp.getPhone_number());
            ps.setString(6, emp.getHire_date());
            ps.setString(7, emp.getJob_id());
            ps.setString(8, emp.getSalary());
            ps.setString(9, emp.getCommission_pct());
            ps.setString(10, emp.getManager_id());
            ps.setString(11, emp.getDepartment_id());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registro Ingresado", "Sistema", 0);
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return false;
    }

    @Override
    public boolean edit(Empleados emp) {
        try {
            con = cn.getConnection();
            String s = "UPDATE EMPLOYEES SET first_name=?,last_name=?,e_mail=?,"
                    + "phone_number=?,hire_date=?,job_id=?,salary=?,commission_pct=?,manager_id=?,departament_id=? WHERE employee_id=?;";
            ps = con.prepareStatement(s);
            ps.setString(1, emp.getFirst_name());
            ps.setString(2, emp.getLast_name());
            ps.setString(3, emp.getE_mail());
            ps.setString(4, emp.getPhone_number());
            ps.setString(5, emp.getHire_date());
            ps.setString(6, emp.getJob_id());
            ps.setString(7, emp.getSalary());
            ps.setString(8, emp.getCommission_pct());
            ps.setString(9, emp.getManager_id());
            ps.setString(10, emp.getDepartment_id());
            ps.setString(11, emp.getEmployee_id());
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);
        }
        return false;
    }

    @Override
    public boolean eliminar(String id) {
        try {
            con = cn.getConnection();
            String consulta = "DELETE FROM EMPLOYEES WHERE employee_id=?;";
            ps = con.prepareStatement(consulta);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (SQLException err) {
            JOptionPane.showMessageDialog(null, err.getMessage(), "Sistema", 0);

        }
        return false;
    }

    @Override
    public List mostrarjcombo1() {
        ArrayList<Empleo> empleos = new ArrayList<>();
        try {
            String consulta = "SELECT * FROM JOBS;";
            Empleo empl = new Empleo();
            con = cn.getConnection();
            ps = con.prepareStatement(consulta);
            rs = ps.executeQuery();
            while (rs.next()) {
                empl.setJob_id(rs.getString("job_id"));
                empl.setJob_title(rs.getString("job_title"));
                empleos.add(empl);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);

        }
        return empleos;

    }

    @Override
    public List mostrarjcombo2() {
        ArrayList<Manager> jefes = new ArrayList<>();
        try {
            String consulta = "SELECT * FROM MANAGER;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta);
            rs = ps.executeQuery();
            while (rs.next()) {
                Manager mang = new Manager();
                mang.setManager_id(rs.getString("manager_id"));
                mang.setManager_name(rs.getString("manager_name"));
                jefes.add(mang);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return jefes;

    }

    @Override
    public List mostrarjcombo3() {
        ArrayList<Departamento> departamentos = new ArrayList<>();
        try {
            String consulta = "SELECT * FROM DEPARTAMENTS;";
            con = cn.getConnection();
            ps = con.prepareStatement(consulta);
            rs = ps.executeQuery();
            while (rs.next()) {
                Departamento dep = new Departamento();
                dep.setDepartament_id(rs.getString("departament_id"));
                dep.setDepartament_name(rs.getString("departament_name"));
                departamentos.add(dep);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Sistema", 0);
        }
        return departamentos;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexion;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Conexion {
  
    DefaultTableModel model;
    public Connection conex;
    public  String driver="com.mysql.jdbc.Driver";
    public  String user="oscar";
    public  String password="hola1234";
    public  String url="jdbc:mysql://192.168.64.2:3306/company";
    public  Statement st=null;
    public  ResultSet rs=null;
    public String Consulta;
    
    public  Conexion(){
    conex=null;
    try{
        Class.forName(driver);
        conex = DriverManager.getConnection(url,user,password);  
        if(conex!=null){
    }
    }catch (ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"error al conectar");
   }
    }
    
public void desconectar(){
    conex=null;
    if(conex==null){
        JOptionPane.showMessageDialog(null,"conexion finalizada");
    }
}
public Connection getConnection(){
    return conex;
}

 

   
    
}

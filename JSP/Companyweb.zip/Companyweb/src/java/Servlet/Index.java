/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import DAO.EmpleadosDAO;
import Model.Empleados;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author oscarfelipecastanomartinez
 */
@WebServlet(name = "index", urlPatterns = {"/controlador"})
public class Index extends HttpServlet {

    String mostrar = "index.jsp";
    String Editar = "Editar.jsp";
    String Agregar = "Agregar.jsp";
    Empleados emp = new Empleados();
    EmpleadosDAO empDAO = new EmpleadosDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accesso = "";
        String action = request.getParameter("accion");
        if (action.equalsIgnoreCase("mostrar")) {
            accesso = mostrar;
        }else if(action.equalsIgnoreCase("add")) {
            accesso=Agregar;
        } else if (action.equalsIgnoreCase("agregar")) {
            String id_employee = request.getParameter("employee_id");
            System.out.println(id_employee);
            String first_name = request.getParameter("first_name");
            String last_name = request.getParameter("last_name");
            String e_mail = request.getParameter("email");
            String phone_number = request.getParameter("phone_number");
            String hire_date = request.getParameter("hire_date");
            String job_id = request.getParameter("job_id");
            String salary = request.getParameter("salary");
            String commission_pct = request.getParameter("commission_pct");
            String manager_id = request.getParameter("manager_id");
            String department_id = request.getParameter("department_id");
            emp.setEmployee_id(id_employee);
            emp.setFirst_name(first_name);
            emp.setLast_name(last_name);
            emp.setE_mail(e_mail);
            emp.setPhone_number(phone_number);
            emp.setHire_date(hire_date);
            emp.setJob_id(job_id);
            emp.setSalary(salary);
            emp.setCommission_pct(commission_pct);
            emp.setManager_id(manager_id);
            emp.setDepartment_id(department_id);
            empDAO.add(emp);
            accesso=mostrar;
        }else if (action.equalsIgnoreCase("eliminar")) {
            String id=request.getParameter("id2");
            emp.setEmployee_id(id);
            empDAO.eliminar(id);
            accesso=mostrar;
        }else if (action.equalsIgnoreCase("modificar")){
            request.setAttribute("id",request.getParameter("idper"));
            accesso=Editar;
        }else if (action.equalsIgnoreCase("actualizar")){
            String id_employee = request.getParameter("employee_id");
            System.out.println(id_employee);
            String first_name = request.getParameter("first_name");
            String last_name = request.getParameter("last_name");
            String e_mail = request.getParameter("email");
            String phone_number = request.getParameter("phone_number");
            String hire_date = request.getParameter("hire_date");
            String job_id = request.getParameter("job_id");
            String salary = request.getParameter("salary");
            String commission_pct = request.getParameter("commission_pct");
            String manager_id = request.getParameter("manager_id");
            String department_id = request.getParameter("department_id");
            emp.setEmployee_id(id_employee);
            emp.setFirst_name(first_name);
            emp.setLast_name(last_name);
            emp.setE_mail(e_mail);
            emp.setPhone_number(phone_number);
            emp.setHire_date(hire_date);
            emp.setJob_id(job_id);
            emp.setSalary(salary);
            emp.setCommission_pct(commission_pct);
            emp.setManager_id(manager_id);
            emp.setDepartment_id(department_id);
            empDAO.edit(emp);
            accesso=mostrar;
        }
        RequestDispatcher vista = request.getRequestDispatcher(accesso);
        vista.forward(request, response);
        
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

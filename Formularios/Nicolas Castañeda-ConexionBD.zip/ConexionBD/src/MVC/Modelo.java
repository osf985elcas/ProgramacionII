/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Nick01348
 */
public class Modelo extends Controlador {
public void Conectar() {
	con=null;
           try {
		Class.forName(driver);
		String conectionBD = url+"="+bdName+";user="+user+";password="+pass+";";
                con = DriverManager.getConnection(conectionBD);
			if (con!=null){
				JOptionPane.showMessageDialog(null,"Conexión establecida");
			}
 		} catch (ClassNotFoundException e){
    JOptionPane.showMessageDialog(null,"Error "+e.getMessage());   
    } catch (SQLException e){
     JOptionPane.showMessageDialog(null,"Error "+e.getMessage());
    } catch (Exception e){
     JOptionPane.showMessageDialog(null,"Error "+e.getMessage());   
    }
}
public Connection getConnection(){
return con;
}
    public void Desconectar(){
    con=null;
    if (con==null){
    JOptionPane.showMessageDialog(null, "Conexión finalizada");
        }
    }
}

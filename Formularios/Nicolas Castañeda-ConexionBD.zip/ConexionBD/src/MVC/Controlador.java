/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;

import java.sql.Connection;

/**
 *
 * @author Nick01348
 */
public class Controlador {
    protected static Connection con = null;
    protected static final String bdName = "proto";
    protected static final String user = "glou";
    protected static final String pass = "root";
    protected static final String driver = "com.mysql.jdbc.Driver";
    protected static final String url = "jdbc:mysql://localhost:3306/nomBD";
}

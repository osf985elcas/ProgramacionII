/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MVC;
import javax.swing.*;
import java.awt.event.*;
/**
 *
 * @author Nick01348
 */
public class Vista extends JFrame implements ActionListener {
     private JButton Conectar,Desconectar;
     public Vista(){
        setLayout(null);
        Conectar=new JButton("Conectar");
        Conectar.setBounds(110,100,90,30);
        add(Conectar);
        Conectar.addActionListener(this);
        Desconectar=new JButton("Desconectar");
        Desconectar.setBounds(210,100,90,30);
        add(Desconectar);
        Desconectar.addActionListener(this);
     }
     public void actionPerformed(ActionEvent e) {
        if (e.getSource()==Conectar) {
            Modelo m = new Modelo();
            m.Conectar();
            m.getConnection();
        }
        if (e.getSource()==Desconectar) {
            Modelo m = new Modelo();
            m.Desconectar();
        }
     }
     public static void main(String[] ar){
        Vista vs=new Vista();
        vs.setBounds(0,0,350,200);
        vs.setVisible(true);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package company.Controlador;
import company.modelo.Modelo;
import company.vista.Usuario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
/**
 *
 * @author Karen Noemi
 */
public class Controlador implements  ActionListener{
    
    private Modelo m;
    private Usuario v;
    
    public Controlador(Modelo m, Usuario v){
        this.m =m;
        this.v=v;
        this.v.conectarDesconectarb.addActionListener(this);
        this.v.Registrarb.addActionListener(this);
    }
    public void  iniciar(){
    v.setTitle("Company");
    v.pack();
    v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    v.setLocationRelativeTo(null);
    v.setVisible(true);
    
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(v.conectarDesconectarb == e.getSource()){
            try{
               m.conectarBaseDatos();
            }catch(Exception ex){
               
            }
            
        }
        if(v.Registrarb == e.getSource()){
            try{
               m.registrar();
            }catch(Exception ex){
               
            }
            
        }
    }

}

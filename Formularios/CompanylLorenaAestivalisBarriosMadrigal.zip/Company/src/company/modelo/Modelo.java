/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package company.modelo;
import company.vista.Usuario;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import static company.vista.Usuario.conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Karen Noemi
 */
public class Modelo {
    private static String  url = "localhost";
    private static String  usuario = "lore";
    private static String baseDatos="company";
    private static String  clave = "144357lob";
    private static int puerto = 1527;
    private static String servidor ="jdbc:derby://"+url+":"+puerto+"/"+baseDatos;
    public static Connection conexion  = null;
    public static PreparedStatement  st=null;
    public static ResultSet rs=null;
    Integer id=0;
    
    Usuario v=new Usuario();

    public static Connection conexion1( ){
        
        
        //Registrar el driver
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
        } catch (ClassNotFoundException e) {
            System.err.println("ERROR AL REGISTRAR EL DRIVER");
            System.exit(0); //parar la ejecución
        }
 
        //Establecer la conexión con el servidor
        try {
            conexion = DriverManager.getConnection(servidor,
                        usuario, clave);
            
        } catch (SQLException e) {
            System.err.println("ERROR AL CONECTAR CON EL SERVIDOR");
            System.exit(0); //parar la ejecución
        }
        System.out.println("Conectado a "+baseDatos);
    return conexion;
    }
    public void iniciarModelo(){
        
    }
    public static void main(String[] args){
        Modelo m= new Modelo();
        m.conexion1();
    }//main
    public void conectarBaseDatos(){
         if(conexion==null){
            conexion=conexion1();
            JOptionPane.showMessageDialog(null,"Base de datos Conectada");
        }else{
            conexion=null;
            JOptionPane.showMessageDialog(null,"Base de datos  Desconectada");
        }
    }
    public void registrar(){
        if(conexion!=null){
            try{
                id=id+1;
                st=conexion.prepareStatement("INSERT INTO REGIONS(REGION_ID, REGION_NAME) VALUES( ?,?)");
                st.setInt(1, id);
                st.setString(2, v.nombret.getText());
                st.executeUpdate();
                st.close();
                JOptionPane.showMessageDialog(null,"Registro agregado");
                
            }catch(SQLException e){
            System.out.println("SQL exception occured" + e.getMessage());
            }//catch
        }else
            JOptionPane.showMessageDialog(null,"La base de datos está desconectada");
    }
    
}

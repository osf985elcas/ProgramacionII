/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package company.Principal;

import company.Controlador.Controlador;
import company.modelo.Modelo;
import company.vista.Usuario;
import javax.swing.UIManager;
import javax.swing.JOptionPane;
/**
 *
 * @author Karen Noemi
 */
public class Principal {
    public static void main(String[] args){
        
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }catch(Exception e ){
            JOptionPane.showMessageDialog(null,e);
        }//catch
        Modelo m =new Modelo();
        Usuario v = new Usuario();
        Controlador c =new Controlador(m, v);
        c.iniciar();
    }
    
}
